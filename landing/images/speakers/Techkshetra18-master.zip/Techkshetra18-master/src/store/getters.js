export default {
    getConfig: state => state.config,
    getEvents: state => state.events,
    getWorkshops: state => state.workshops
}
