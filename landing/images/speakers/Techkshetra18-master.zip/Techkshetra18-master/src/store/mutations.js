export default {
    PUSH_EVENT (state, event) {
        state.events = event
    },
    PUSH_WORKSHOP (state, workshop) {
        state.workshops = workshop
    }
}
