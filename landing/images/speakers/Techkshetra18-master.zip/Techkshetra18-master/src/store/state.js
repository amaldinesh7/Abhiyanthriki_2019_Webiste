export default {
    config: {
        apiKey: 'AIzaSyC7P3DLKzKUwT2CKhBsjik75VR4-lzpXQI',
        authDomain: 'projectm1-94d36.firebaseapp.com',
        databaseURL: 'https://projectm1-94d36.firebaseio.com',
        projectId: 'projectm1-94d36',
        storageBucket: 'projectm1-94d36.appspot.com',
        messagingSenderId: '200497519300'
    },
    events: [],
    workshops: []
}
